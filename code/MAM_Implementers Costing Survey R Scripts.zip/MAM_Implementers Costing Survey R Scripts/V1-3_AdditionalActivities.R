#clear R/load libraries/upload raw df
rm(list=ls())
library (readr)
library(dplyr)
library(ggplot2)
library(mosaic)
library(tidyr)
library(writexl)
#import, readr downloaded data then rename as Raw_SITMAAT_WeekEx
Raw_SITTMAAT_WeekEx <- SITT_MAT_Weekly_Implementation_Activity_Survey_for_SITT_MAT_Team_May_19_2023_11_47
  
#goal: name, start date, end date, category, activity details, mins, hrs
#subset df w/o metadata, first 2 rows, "not involved in SITTMAT"
SITTMAAT_WeekEx <-select(Raw_SITTMAAT_WeekEx, -0:-17)
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[-1,]
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[-1,]
SITTMAAT_WeekEx <-select(SITTMAAT_WeekEx, -4)
View (SITTMAAT_WeekEx)
#subset with only additional ones
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[, c("Q1", "Q2", "Q3", "Q12_1","Q12_2","Q12_3","Q12_4","Q12_5", "Q13")]

#renaming columns
colnames(SITTMAAT_WeekEx)[1]= "Name"
colnames(SITTMAAT_WeekEx)[2]= "Start Date"
colnames(SITTMAAT_WeekEx)[3]= "End Date"
colnames(SITTMAAT_WeekEx)[4]= "Additionalactivity1_notes"
colnames(SITTMAAT_WeekEx)[5]= "Additionalactivity2_notes"
colnames(SITTMAAT_WeekEx)[6]= "Additionalactivity3_notes"
colnames(SITTMAAT_WeekEx)[7]= "Additionalactivity4_notes"
colnames(SITTMAAT_WeekEx)[8]= "Additionalactivity5_notes"
colnames(SITTMAAT_WeekEx)[9]= "Additionalcosting_notes"
View(SITTMAAT_WeekEx)

#WIDE TO LONG FORM (Category/Activity/EstMin)
SITTMAAT_WeekEx = SITTMAAT_WeekEx %>%
  pivot_longer(cols = ends_with("notes"))
View(SITTMAAT_WeekEx)
#renaming of final df
colnames(SITTMAAT_WeekEx)[4]= "Activity"
colnames(SITTMAAT_WeekEx)[5]= "Notes"
#omit na rows
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[!(is.na(SITTMAAT_WeekEx$Notes)), ]
View(SITTMAAT_WeekEx)
#add activity category column
SITTMAAT_Cleaned = SITTMAAT_WeekEx %>% mutate(Category = case_when(
  startsWith(Activity, "Additionalactivity") ~ "Additional Activities",
  startsWith(Activity, "Additionalcosting") ~ "Additional Costing", 
  T ~ NA_character_))
SITTMAAT_Cleaned <- select(SITTMAAT_Cleaned, -Activity)
View(SITTMAAT_Cleaned)

#transfer to new excel sheet
write_xlsx(SITTMAAT_Cleaned, "CleanedMay18.xlsx")


