#clear R/load libraries/upload raw df
rm(list=ls())
library (readr)
library(dplyr)
library(ggplot2)
library(mosaic)
library(tidyr)
library(writexl)
#import, readr downloaded data then rename as Raw_SITMAAT_WeekEx
Raw_SITTMAAT_WeekEx <- SITT_MAT_Weekly_Implementation_Activity_Survey_for_SITT_MAT_Team_April_24_2023_21_34

#goal: name, start date, end date, category, activity details, mins, hrs
#subset df w/o metadata, first 2 rows, "not involved in SITTMAT"
SITTMAAT_WeekEx <-select(Raw_SITTMAAT_WeekEx, -0:-17)
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[-1,]
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[-1,]
SITTMAAT_WeekEx <- subset(SITTMAAT_WeekEx, Q4 ==  "No (Note: selecting this will take you to the end of survey)")
SITTMAAT_NotInvolved <- subset(SITTMAAT_WeekEx, select = c("Q1", "Q2", "Q3"))

#renaming columns
colnames(SITTMAAT_NotInvolved)[1]= "Name"
colnames(SITTMAAT_NotInvolved)[2]= "Start Date"
colnames(SITTMAAT_NotInvolved)[3]= "End Date"
View (SITTMAAT_NotInvolved)

#transfer to new excel sheet
write_xlsx(SITTMAAT_NotInvolved, "NotInvolvedSITTMAT_April24.xlsx")
