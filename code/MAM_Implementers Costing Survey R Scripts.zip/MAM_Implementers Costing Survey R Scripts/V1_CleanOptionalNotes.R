#clear R/load libraries/upload raw df
rm(list=ls())
library (readr)
library(dplyr)
library(ggplot2)
library(mosaic)
library(tidyr)
library(writexl)
#import, readr downloaded data then rename as Raw_SITMAAT_WeekEx
Raw_SITTMAAT_WeekEx <- SITT_MAT_Weekly_Implementation_Activity_Survey_for_SITT_MAT_Team_June_13_2023_11_57
#goal: activity - category, activity details, est time(min), est time (hr), notes
#subset df w/o metadata, first 2 rows, "not involved in SITTMAT"
SITTMAAT_WeekEx <-select(Raw_SITTMAAT_WeekEx, -0:-17)
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[-1,]
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[-1,]
SITTMAAT_WeekEx <- subset(SITTMAAT_WeekEx, Q4 == "Yes")
SITTMAAT_WeekEx <-select(SITTMAAT_WeekEx, -4)

#renaming columns
colnames(SITTMAAT_WeekEx)[1]= "Name"
colnames(SITTMAAT_WeekEx)[2]= "Start Date"
colnames(SITTMAAT_WeekEx)[3]= "End Date"
#activities: #Column name: Type_activity_mins (ex. R_calls_minutes )
#Q4 was SITTMAT involvement - all "no"s were taken out
#following columns index position is its Q#-1
colnames(SITTMAAT_WeekEx)[4]= "R_meetings_mins"
colnames(SITTMAAT_WeekEx)[5]= "R_meetings_notes"
colnames(SITTMAAT_WeekEx)[6]= "R_materials_mins"
colnames(SITTMAAT_WeekEx)[7]= "R_materials_notes"
colnames(SITTMAAT_WeekEx)[8]= "R_emails_mins"
colnames(SITTMAAT_WeekEx)[9]= "R_emails_notes"
colnames(SITTMAAT_WeekEx)[10]= "R_calls_mins"
colnames(SITTMAAT_WeekEx)[11]= "R_calls_notes"
colnames(SITTMAAT_WeekEx)[12]= "R_participantcalls_mins"
colnames(SITTMAAT_WeekEx)[13]= "R_participants_notes"
colnames(SITTMAAT_WeekEx)[14]= "R_stakeholders_mins"
colnames(SITTMAAT_WeekEx)[15]= "R_stakeholders_notes"
colnames(SITTMAAT_WeekEx)[16]= "R_infowebinar_prep_mins"
colnames(SITTMAAT_WeekEx)[17]= "R_infowebinar_prep_notes"
colnames(SITTMAAT_WeekEx)[18]= "R_infowebinar_host_mins"
colnames(SITTMAAT_WeekEx)[19]= "R_infowebinar_host_notes"
colnames(SITTMAAT_WeekEx)[20]= "R_kickoffwebinar_prep_mins"
colnames(SITTMAAT_WeekEx)[21]= "R_kickoffwebinar_prep_notes"
colnames(SITTMAAT_WeekEx)[22]= "R_kickoffwebinar_host_mins"
colnames(SITTMAAT_WeekEx)[23]= "R_kickoffwebinar_host_notes"

colnames(SITTMAAT_WeekEx)[24]= "EMF_meetings_mins"
colnames(SITTMAAT_WeekEx)[25]= "EMF_meetings_notes"
colnames(SITTMAAT_WeekEx)[26]= "EMF_datacollection_mins"
colnames(SITTMAAT_WeekEx)[27]= "EMF_datacollection_notes"
colnames(SITTMAAT_WeekEx)[28]= "EMF_REDCap_mins"
colnames(SITTMAAT_WeekEx)[29]= "EMF_REDCap_notes"
colnames(SITTMAAT_WeekEx)[30]= "EMF_dashboard_mins"
colnames(SITTMAAT_WeekEx)[31]= "EMF_dashboard_notes"
colnames(SITTMAAT_WeekEx)[32]= "EMF_reporttemplate_mins"
colnames(SITTMAAT_WeekEx)[33]= "EMF_reporttemplate_notes"
colnames(SITTMAAT_WeekEx)[34]= "EMF_IMATcalculations_mins"
colnames(SITTMAAT_WeekEx)[35]= "EMF_IMATcalculations_notes"
colnames(SITTMAAT_WeekEx)[36]= "EMF_datawebinar_prep_mins"
colnames(SITTMAAT_WeekEx)[37]= "EMF_datawebinar_prep_notes"
colnames(SITTMAAT_WeekEx)[38]= "EMF_datawebinar_invite_mins"
colnames(SITTMAAT_WeekEx)[39]= "EMF_datawebinar_invite_notes"
colnames(SITTMAAT_WeekEx)[40]= "EMF_datawebinar_host_mins"
colnames(SITTMAAT_WeekEx)[41]= "EMF_datawebinar_host_notes"
colnames(SITTMAAT_WeekEx)[42]= "EMF_datainquiries_mins"
colnames(SITTMAAT_WeekEx)[43]= "EMF_datainquiries_notes"
colnames(SITTMAAT_WeekEx)[44]= "EMF_IMATandpatient_inforequest_mins"
colnames(SITTMAAT_WeekEx)[45]= "EMF_IMATandpatient_inforequest_notes"
colnames(SITTMAAT_WeekEx)[46]= "EMF_IMATandpatient_analysis_mins"
colnames(SITTMAAT_WeekEx)[47]= "EMF_IMATandpatient_analysis_notes"
colnames(SITTMAAT_WeekEx)[48]= "EMF_generatereport_mins"
colnames(SITTMAAT_WeekEx)[49]= "EMF_generatereport_notes"
colnames(SITTMAAT_WeekEx)[50]= "EMF_returnreport_mins"
colnames(SITTMAAT_WeekEx)[51]= "EMF_returnreport_notes"

colnames(SITTMAAT_WeekEx)[52]= "NIATxMAT_meetings_mins"
colnames(SITTMAAT_WeekEx)[53]= "NIATxMAT_meetings_notes"
colnames(SITTMAAT_WeekEx)[54]= "NIATxMAT_academyplan_mins"
colnames(SITTMAAT_WeekEx)[55]= "NIATxMAT_academyplan_notes"
colnames(SITTMAAT_WeekEx)[56]= "NIATxMAT_academyinvites_mins"
colnames(SITTMAAT_WeekEx)[57]= "NIATxMAT_academyinvites_notes"
colnames(SITTMAAT_WeekEx)[58]= "NIATxMAT_academyattend_mins"
colnames(SITTMAAT_WeekEx)[59]= "NIATxMAT_academyattend_notes"
colnames(SITTMAAT_WeekEx)[60]= "NIATxMAT_academyparticipation_mins"
colnames(SITTMAAT_WeekEx)[61]= "NIATxMAT_academyparticipation_notes"

colnames(SITTMAAT_WeekEx)[62]= "InternalF_meetings_mins"
colnames(SITTMAAT_WeekEx)[63]= "InternalF_meetings_notes"
colnames(SITTMAAT_WeekEx)[64]= "InternalF_content_mins"
colnames(SITTMAAT_WeekEx)[65]= "InternalF_content_notes"
colnames(SITTMAAT_WeekEx)[66]= "InternalF_datacollection_mins"
colnames(SITTMAAT_WeekEx)[67]= "InternalF_datacollection_notes"
colnames(SITTMAAT_WeekEx)[68]= "InternalF_invites_mins"
colnames(SITTMAAT_WeekEx)[69]= "InternalF_invites_notes"
colnames(SITTMAAT_WeekEx)[70]= "InternalF_identifiedchangeleader_mins"
colnames(SITTMAAT_WeekEx)[71]= "InternalF_identifiedchangeleader_notes"
colnames(SITTMAAT_WeekEx)[72]= "InternalF_trackedsiteparticipation_mins"
colnames(SITTMAAT_WeekEx)[73]= "InternalF_trackedsiteparticipation_notes"
colnames(SITTMAAT_WeekEx)[74]= "InternalF_ledcoachcalls_mins"
colnames(SITTMAAT_WeekEx)[75]= "InternalF_ledcoachcalls_notes"
colnames(SITTMAAT_WeekEx)[76]= "InternalF_additionalsupport_mins"
colnames(SITTMAAT_WeekEx)[77]= "InternalF_additionalsupport_notes"

colnames(SITTMAAT_WeekEx)[78]= "ExternalF_meetings_mins"
colnames(SITTMAAT_WeekEx)[79]= "ExternalF_meetings_notes"
colnames(SITTMAAT_WeekEx)[80]= "ExternalF_content_mins"
colnames(SITTMAAT_WeekEx)[81]= "ExternalF_content_notes"
colnames(SITTMAAT_WeekEx)[82]= "ExternalF_datasystems_mins"
colnames(SITTMAAT_WeekEx)[83]= "ExternalF_datasystems_notes"
colnames(SITTMAAT_WeekEx)[84]= "ExternalF_participantinvites_mins"
colnames(SITTMAAT_WeekEx)[85]= "ExternalF_participantinvites_notes"
colnames(SITTMAAT_WeekEx)[86]= "ExternalF_trackedsiteparticipation_mins"
colnames(SITTMAAT_WeekEx)[87]= "ExternalF_trackedsiteparticipation_notes"
colnames(SITTMAAT_WeekEx)[88]= "ExternalF_ledcoachcalls_mins"
colnames(SITTMAAT_WeekEx)[89]= "ExternalF_ledcoachcalls_notes"
colnames(SITTMAAT_WeekEx)[90]= "ExternalF_additionalsupport_mins"
colnames(SITTMAAT_WeekEx)[91]= "ExternalF_additionalsupport_notes"

colnames(SITTMAAT_WeekEx)[92]= "SIC/COINS_meetings_mins"
colnames(SITTMAAT_WeekEx)[93]= "SIC/COINS_meetings_notes"
colnames(SITTMAAT_WeekEx)[94]= "SIC/COINS_content_mins"
colnames(SITTMAAT_WeekEx)[95]= "SIC/COINS_content_notes"
colnames(SITTMAAT_WeekEx)[96]= "SIC/COINS_trackedinfo_mins"
colnames(SITTMAAT_WeekEx)[97]= "SIC/COINS_trackedinfo_notes"
colnames(SITTMAAT_WeekEx)[98]= "SIC/COINS_fidelityscale_mins"
colnames(SITTMAAT_WeekEx)[99]= "SIC/COINS_fidelityscale_notes"
colnames(SITTMAAT_WeekEx)[100]= "SIC/COINS_sustainementscale_mins"
colnames(SITTMAAT_WeekEx)[101]= "SIC/COINS_sustainementscale_notes"
colnames(SITTMAAT_WeekEx)[102]= "SIC/COINS_implementationtracker_mins"
colnames(SITTMAAT_WeekEx)[103]= "SIC/COINS_implementationtracker_notes"
colnames(SITTMAAT_WeekEx)[104]= "SIC/COINS_data_mins"
colnames(SITTMAAT_WeekEx)[105]= "SIC/COINS_data_notes"

colnames(SITTMAAT_WeekEx)[108]= "SITMAATTeam_meetings_mins"
colnames(SITTMAAT_WeekEx)[109]= "SITMAATTeam_meetings_notes"
colnames(SITTMAAT_WeekEx)[110]= "SITMAATTeam_costsurvey_mins"
colnames(SITTMAAT_WeekEx)[103]= "SITMAATTeam_costsurvey_notes"
colnames(SITTMAAT_WeekEx)[104]= "SITMAATTeam_costdata_mins"
colnames(SITTMAAT_WeekEx)[105]= "SITMAATTeam_costdata_notes"

colnames(SITTMAAT_WeekEx)[106]= "SITMAATTeam_ledcoachcalls_mins"
colnames(SITTMAAT_WeekEx)[107]= "SITMAATTeam_ledcoachcalls_notes"
colnames(SITTMAAT_WeekEx)[108]= "SITMAATTeam_additionalsupport_mins"
colnames(SITTMAAT_WeekEx)[109]= "SITMAATTeam_additionalsupport_notes"
colnames(SITTMAAT_WeekEx)[110]= "SITMAATTeam__notes"
colnames(SITTMAAT_WeekEx)[111]= "SITMAATTeam__notes"

colnames(SITTMAAT_WeekEx)[112]= "additionalactivity_notes"
colnames(SITTMAAT_WeekEx)[113]= "additionalactivity_notes"
colnames(SITTMAAT_WeekEx)[114]= "additionalactivity_notes"
colnames(SITTMAAT_WeekEx)[115]= "additionalactivity_notes"
colnames(SITTMAAT_WeekEx)[116]= "additionalactivity_notes"
colnames(SITTMAAT_WeekEx)[117]= "additionalcosting_notes"

#WIDE TO LONG FORM (Category/Activity/EstMin)
SITTMAAT_WeekEx = SITTMAAT_WeekEx %>%
  pivot_longer(cols = c(ends_with("mins"), ends_with("notes")),
               names_pattern = "(.+)_([a-z]+)",
               names_to = c("Activity", ".value"))
View(SITTMAAT_WeekEx)
#renaming of final df
colnames(SITTMAAT_WeekEx)[4]= "Activity"
colnames(SITTMAAT_WeekEx)[5]= "Mins"
colnames(SITTMAAT_WeekEx)[6]= "Optional Notes"
#omit na rows
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[!(is.na(SITTMAAT_WeekEx$Mins)), ]
#mins --> hrs
SITTMAAT_WeekEx$Mins <- as.numeric(as.character(SITTMAAT_WeekEx$Mins)) 
SITTMAAT_WeekEx$Hrs = SITTMAAT_WeekEx$Mins/60
View(SITTMAAT_WeekEx)
#add activity category column
SITTMAAT_Cleaned = SITTMAAT_WeekEx %>% mutate(Category = case_when(
  startsWith(Activity, "R_") ~ "Recruitment",
  startsWith(Activity, "EMF_") ~ "EMF",
  startsWith(Activity, "NIATxMAT_") ~ "NIATxMAT Academy",
  startsWith(Activity, "InternalF_") ~ "Internal Facilitation",
  startsWith(Activity, "ExternalF_") ~ "External Facilitation",
  startsWith(Activity, "SIC/COINS_") ~ "SIC/COINS",
  startsWith(Activity, "SITMAATTeam_") ~ "SITMAAT Purveyor Team", 
  startsWith(Activity, "additionalactivity") ~ "Additional Relevant Activities",
  startsWith(Activity, "additionalcosting_") ~ "Additional Costing Tasks", 
  T ~ NA_character_))
View(SITTMAAT_Cleaned)

#transfer to new excel sheet
write_xlsx(SITTMAAT_Cleaned, "CostingComments_Before10.17.xlsx")


