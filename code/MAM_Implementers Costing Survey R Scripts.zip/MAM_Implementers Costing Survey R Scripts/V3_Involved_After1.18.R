#clear R/load libraries/upload raw df
rm(list=ls())
library (readr)
library(dplyr)
library(ggplot2)
library(mosaic)
library(tidyr)
library(writexl)
#import, readr downloaded data then rename as Raw_SITMAAT_WeekEx
Raw_SITTMAAT_WeekEx <- SITT_MAT_Weekly_Implementation_Activity_Survey_for_SITT_MAT_Team_April_4_2023_23_39_3

#goal: name, start date, end date, category, activity details, mins, hrs
#subset df w/o metadata, first 2 rows, "not involved in SITTMAT"
SITTMAAT_WeekEx <-select(Raw_SITTMAAT_WeekEx, -0:-17)
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[-1,]
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[-1,]
SITTMAAT_WeekEx <- subset(SITTMAAT_WeekEx, Q4 == "Yes")
SITTMAAT_WeekEx <-select(SITTMAAT_WeekEx, -4)

#renaming columns
colnames(SITTMAAT_WeekEx)[1]= "Name"
colnames(SITTMAAT_WeekEx)[2]= "Start Date"
colnames(SITTMAAT_WeekEx)[3]= "End Date"

#activities: #Column name: Type_activity_mins (ex. R_calls_minutes )
#Q4 was SITTMAT involvement - all "no"s were taken out
#following columns index position is its Q#-1
colnames(SITTMAAT_WeekEx)[4]= "EMF_meetings_mins"
colnames(SITTMAAT_WeekEx)[5]= "EMF_meetings_notes"
colnames(SITTMAAT_WeekEx)[6]= "EMF_datacollection_mins"
colnames(SITTMAAT_WeekEx)[7]= "EMF_datacollection_notes"
colnames(SITTMAAT_WeekEx)[8]= "EMF_REDCap_mins"
colnames(SITTMAAT_WeekEx)[9]= "EMF_REDCap_notes"
colnames(SITTMAAT_WeekEx)[10]= "EMF_dashboard_mins"
colnames(SITTMAAT_WeekEx)[11]= "EMF_dashboard_notes"
colnames(SITTMAAT_WeekEx)[12]= "EMF_reporttemplate_mins"
colnames(SITTMAAT_WeekEx)[13]= "EMF_reporttemplate_notes"
colnames(SITTMAAT_WeekEx)[14]= "EMF_IMATcalculations_mins"
colnames(SITTMAAT_WeekEx)[15]= "EMF_IMATcalculations_notes"
colnames(SITTMAAT_WeekEx)[16]= "EMF_datawebinar_prep_mins"
colnames(SITTMAAT_WeekEx)[17]= "EMF_datawebinar_prep_notes"
colnames(SITTMAAT_WeekEx)[18]= "EMF_datawebinar_invite_mins"
colnames(SITTMAAT_WeekEx)[19]= "EMF_datawebinar_invite_notes"
colnames(SITTMAAT_WeekEx)[20]= "EMF_datawebinar_host_mins"
colnames(SITTMAAT_WeekEx)[21]= "EMF_datawebinar_host_notes"
colnames(SITTMAAT_WeekEx)[22]= "EMF_datainquiries_mins"
colnames(SITTMAAT_WeekEx)[23]= "EMF_datainquiries_notes"
colnames(SITTMAAT_WeekEx)[24]= "EMF_ServiceRegistry_inforequest_mins"
colnames(SITTMAAT_WeekEx)[25]= "EMF_ServiceRegistry_inforequest_notes"
colnames(SITTMAAT_WeekEx)[26]= "EMF_ServiceRegistry_validation_mins"
colnames(SITTMAAT_WeekEx)[27]= "EMF_ServiceRegistry_validation_notes"
colnames(SITTMAAT_WeekEx)[28]= "EMF_ServiceRegistry_analysis_mins"
colnames(SITTMAAT_WeekEx)[29]= "EMF_ServiceRegistry_analysis_notes"
colnames(SITTMAAT_WeekEx)[30]= "EMF_generatereport_mins"
colnames(SITTMAAT_WeekEx)[31]= "EMF_generatereport_notes"
colnames(SITTMAAT_WeekEx)[32]= "EMF_returnreport_mins"
colnames(SITTMAAT_WeekEx)[33]= "EMF_returnreport_notes"

colnames(SITTMAAT_WeekEx)[34]= "NIATxMAT_meetings_mins"
colnames(SITTMAAT_WeekEx)[35]= "NIATxMAT_meetings_notes"
colnames(SITTMAAT_WeekEx)[36]= "NIATxMAT_academyplan_mins"
colnames(SITTMAAT_WeekEx)[37]= "NIATxMAT_academyplan_notes"
colnames(SITTMAAT_WeekEx)[38]= "NIATxMAT_academyinvites_mins"
colnames(SITTMAAT_WeekEx)[39]= "NIATxMAT_academyinvites_notes"
colnames(SITTMAAT_WeekEx)[40]= "NIATxMAT_academyparticipation_mins"
colnames(SITTMAAT_WeekEx)[41]= "NIATxMAT_academyparticipation_notes"

colnames(SITTMAAT_WeekEx)[42]= "InternalF_meetings_mins"
colnames(SITTMAAT_WeekEx)[43]= "InternalF_meetings_notes"
colnames(SITTMAAT_WeekEx)[44]= "InternalF_content_mins"
colnames(SITTMAAT_WeekEx)[45]= "InternalF_content_notes"
colnames(SITTMAAT_WeekEx)[46]= "InternalF_datacollection_mins"
colnames(SITTMAAT_WeekEx)[47]= "InternalF_datacollection_notes"
colnames(SITTMAAT_WeekEx)[48]= "InternalF_invites_mins"
colnames(SITTMAAT_WeekEx)[49]= "InternalF_invites_notes"
colnames(SITTMAAT_WeekEx)[50]= "InternalF_identifiedchangeleader_mins"
colnames(SITTMAAT_WeekEx)[51]= "InternalF_identifiedchangeleader_notes"
colnames(SITTMAAT_WeekEx)[52]= "InternalF_trackedsiteparticipation_mins"
colnames(SITTMAAT_WeekEx)[53]= "InternalF_trackedsiteparticipation_notes"
colnames(SITTMAAT_WeekEx)[54]= "InternalF_ledcoachcalls_mins"
colnames(SITTMAAT_WeekEx)[55]= "InternalF_ledcoachcalls_notes"
colnames(SITTMAAT_WeekEx)[56]= "InternalF_additionalsupport_mins"
colnames(SITTMAAT_WeekEx)[57]= "InternalF_additionalsupport_notes"

colnames(SITTMAAT_WeekEx)[58]= "ExternalF_meetings_mins"
colnames(SITTMAAT_WeekEx)[59]= "ExternalF_meetings_notes"
colnames(SITTMAAT_WeekEx)[60]= "ExternalF_content_mins"
colnames(SITTMAAT_WeekEx)[61]= "ExternalF_content_notes"
colnames(SITTMAAT_WeekEx)[62]= "ExternalF_datasystems_mins"
colnames(SITTMAAT_WeekEx)[63]= "ExternalF_datasystems_notes"
colnames(SITTMAAT_WeekEx)[64]= "ExternalF_participantinvites_mins"
colnames(SITTMAAT_WeekEx)[65]= "ExternalF_participantinvites_notes"
colnames(SITTMAAT_WeekEx)[66]= "ExternalF_trackedsiteparticipation_mins"
colnames(SITTMAAT_WeekEx)[67]= "ExternalF_trackedsiteparticipation_notes"
colnames(SITTMAAT_WeekEx)[68]= "ExternalF_ledcoachcalls_mins"
colnames(SITTMAAT_WeekEx)[69]= "ExternalF_ledcoachcalls_notes"
colnames(SITTMAAT_WeekEx)[70]= "ExternalF_additionalsupport_mins"
colnames(SITTMAAT_WeekEx)[71]= "ExternalF_additionalsupport_notes"

colnames(SITTMAAT_WeekEx)[72]= "SIC/COINS_meetings_mins"
colnames(SITTMAAT_WeekEx)[73]= "SIC/COINS_meetings_notes"
colnames(SITTMAAT_WeekEx)[74]= "SIC/COINS_content_mins"
colnames(SITTMAAT_WeekEx)[75]= "SIC/COINS_content_notes"
colnames(SITTMAAT_WeekEx)[76]= "SIC/COINS_trackedinfo_mins"
colnames(SITTMAAT_WeekEx)[77]= "SIC/COINS_trackedinfo_notes"
colnames(SITTMAAT_WeekEx)[78]= "SIC/COINS_fidelityscale_mins"
colnames(SITTMAAT_WeekEx)[79]= "SIC/COINS_fidelityscale_notes"
colnames(SITTMAAT_WeekEx)[80]= "SIC/COINS_sustainementscale_mins"
colnames(SITTMAAT_WeekEx)[81]= "SIC/COINS_sustainementscale_notes"
colnames(SITTMAAT_WeekEx)[82]= "SIC/COINS_developedtracker_mins"
colnames(SITTMAAT_WeekEx)[83]= "SIC/COINS_developedtracker_notes"
colnames(SITTMAAT_WeekEx)[84]= "SIC/COINS_validation_mins"
colnames(SITTMAAT_WeekEx)[85]= "SIC/COINS_validation_notes"
colnames(SITTMAAT_WeekEx)[86]= "SIC/COINS_data_mins"
colnames(SITTMAAT_WeekEx)[87]= "SIC/COINS_data_notes"

colnames(SITTMAAT_WeekEx)[88]= "SITMAATTeam_meetings_mins"
colnames(SITTMAAT_WeekEx)[89]= "SITMAATTeam_meetings_notes"
colnames(SITTMAAT_WeekEx)[90]= "SITMAATTeam_costsurvey_mins"
colnames(SITTMAAT_WeekEx)[91]= "SITMAATTeam_costsurvey_notes"
colnames(SITTMAAT_WeekEx)[92]= "SITMAATTeam_validatecostsurvey_mins"
colnames(SITTMAAT_WeekEx)[93]= "SITMAATTeam_validatecostsurvey_notes"
colnames(SITTMAAT_WeekEx)[94]= "SITMAATTeam_costdata_mins"
colnames(SITTMAAT_WeekEx)[95]= "SITMAATTeam_costdata_notes"

colnames(SITTMAAT_WeekEx)[96]= "additionalactivity_notes"
colnames(SITTMAAT_WeekEx)[97]= "additionalactivity_notes"
colnames(SITTMAAT_WeekEx)[98]= "additionalactivity_notes"
colnames(SITTMAAT_WeekEx)[99]= "additionalactivity_notes"
colnames(SITTMAAT_WeekEx)[100]= "additionalactivity_notes"
colnames(SITTMAAT_WeekEx)[101]= "additionalcosting_notes"

#WIDE TO LONG FORM (Category/Activity/EstMin)
SITTMAAT_WeekEx = SITTMAAT_WeekEx %>%
  select(!ends_with("notes")) %>%
  pivot_longer(cols = ends_with("mins"))
View(SITTMAAT_WeekEx)
#renaming of final df
colnames(SITTMAAT_WeekEx)[4]= "Activity"
colnames(SITTMAAT_WeekEx)[5]= "Mins"
#omit na rows
SITTMAAT_WeekEx <- SITTMAAT_WeekEx[!(is.na(SITTMAAT_WeekEx$Mins)), ]
#mins --> hrs
SITTMAAT_WeekEx$Mins <- as.numeric(as.character(SITTMAAT_WeekEx$Mins)) 
SITTMAAT_WeekEx$Hrs = SITTMAAT_WeekEx$Mins/60

#add activity category column
SITTMAAT_Cleaned = SITTMAAT_WeekEx %>% mutate(Category = case_when(
  startsWith(Activity, "EMF_") ~ "EMF",
  startsWith(Activity, "NIATxMAT_") ~ "NIATxMAT Academy",
  startsWith(Activity, "InternalF_") ~ "Internal Facilitation",
  startsWith(Activity, "ExternalF_") ~ "External Facilitation",
  startsWith(Activity, "SIC/COINS_") ~ "SIC/COINS",
  startsWith(Activity, "SITMAATTeam_") ~ "SITMAAT Purveyor Team", 
  startsWith(Activity, "additionalactivity") ~ "Additional Relevant Activities",
  startsWith(Activity, "additionalcosting_") ~ "Additional Costing Tasks", 
  T ~ NA_character_))
View(SITTMAAT_Cleaned)

#transfer to new excel sheet
write_xlsx(SITTMAAT_Cleaned, "CleanedSITTMAT_April4.xlsx")


